# Commando NES with SDL by gets(name);

## Description of the game

This is Commando, a video game developed for Nintendo Entertainment System in 1986 by Capcom.
The game is takes place in a ficcional war and soldier Super Joe(the main character) has to fight
his way out singlehandedly, fending off a massive assault of enemy soldiers.

## Members

- Managmnet:
Sandra Alvarez

- QA:
Aleix Castillo

- Art:
Guillem Costa

- Code:
Aleix Gabarr�

## Inputs

Global Inputs

'F1' to show colliders.

'F2' to enable god mode.

'F3' to disable god mode.
'Z,X,C,V,B' to change map zone.
'N' add grenades.
'1,2,3,4,5' for going to the secret rooms.
'Enter' for 'OK'.


1 Player:

'WASD' for move the character.

'Left shift' to throw grenades.

'Space' to shoot.


Player 2:

Keyboard arrows' to move the character
'Intro keypad' shoot the sub-machine gun.
'Right contorl' throw grenades foward.
'0 Keyoad' revive ally.
 
Gamepad inputs(xbos 360) for both players:

'B' move options in start menu.
'A' to select option.

'Joysticks' move players.
'B' throw grenade.
'A'shoot the sub-machine gun.
'X' revive ally.
'Start' god mode on.
'Back' god mode off.

## Knwon bugs in 1.0 version

The player cannot shoot in the up-left diagonal.
If the player is under the bridge and he presses 'Space', he will shoot in the same direction he shoot last time.
If F1 is enabled, a small collider appears near the first rock.
While the Super Joe dead animation is on, the player can still shoot and increase his score killing.
At the strat one enemy dissapers in some sprites.
A few soldiers don't have colliders and they are only an animation(most of then athe the last zones).
When you kill the Shield soldier you are able to win the level but the enemy soldiers continue to appears.
In the Secret Room D if you die you can move also if you are in god mode the character might ingnore the stairs animation.
You can shoot the Shield soldier to increase your total points.



## Changelist of all previous versions

### Version 0.1
-Empty scrolling background.
-Background scrolling itself.
-Player moving without collisions.
-Player animated while moving.
-One song playing while the game is running.

### Version 0.2
-4 new modules for 4 new scenes.
-Scrolling only working at first and second scenes.
-Player implemented at first and second scenes.
-Music playing only on playable screens.
-Fade to black working well.
-User can swap between screens pressing Space.

### Version 0.3
-Player and camera limits.
-Implemented bullets' sound effect when player shoots.

### Version 0.4
-Motorbike enemy animation working.
-Colliders for the player implemented and working.
-Particles colliders working well.
-Menu selection implemented.

### Version 0.45
-Added all enemies.
-Trying to make a random path for enemies.
-Enemies shooting to the player.
-Helicopter cinematic implemented.
-Fixing colliders.

### Version 0.46
-Items working well.
-Fixing colliders.
-Bridge implementation.

### Version 0.47
-Highscore and HUD parcially implemented.
-Fixed some bugs.
-Player initial position fixed.
-Camera hardly optimized.
-Module savedata implemented for highscore.
-Fixing colliders.
-Prisoners paths implemented.
-Green soldiers path implemented.
-Bridge implementation fixed.

### Version 0.48
-Hihgscore and HUD working well.
-Fixing colliders.
-Prisoners paths fixed.
-Grenade implemented.
-Win condition.
-Knife soldiers paths implemented.
-Some memory leaks fixed.

### Version 0.48.5
-Grenade working well at all.
-Colliders fixed.
-Sprites Knife soldiers fixed.
-0 memory leaks.

### Version 0.49
-Folders for each PNG and audios implemented.
-Fixed colliders that make player get stuck when he collides with COLLIDER_WALL.

### Version 0.5
-Some bugs fixed.
-Final victory and lose scene implemented with music.

### Version 0.6

-Implemented the Secret Rooms.
-Implemented the secret staris.
-Implemented the entrance to the rooms.
-Implmented the fast acces to the new rooms.
-Fixed some general bugs.

### Version 0.7

-Implemented the 2nd player mode.
-Full implemented secret rooms.
-Added win cinematic.
-Fixed some soldier bugs.
-Fixed some general bugs.
-Implemented soldier paths.
-Implemented revive mode.
-Implemented all items of the game including first aid kids(not the radio).
-Implemented all power ups.
-Now we shoot with space and throw grenades with the left shift.
-Camera is only working for 1st player.
-Implemented the ending scene.
-Implemented the radio cinematic.
-The enemies soldiers also follow the main character.
-HUD is working well and the save data is fixed.


### Version 0.81
-Fixed grenades bugs.
-Implemented the radio item with the cinematic.
-The enemies also follow the second player when the 1st player dies.
-Some audio bugs fixed.

### Version 0.82
-Fixed secret rooms bugs.
-All audios fixed.
-All the cinematics fixed.
-Added Game Over screen.


### Version 0.9

-Implemented the way to entrance to the secret rooms.
-Added the blocked entrance to the rooms if you entered before.
-All the items fixed and working well.



### Version 1.0
-Final scene fixed and working well.
-Win condicion fixed.
-Lose condition fixed.
-2players mode working well.




