//LNK error de linker -- Si no es de compilador
#include <stdlib.h>
#include "include\SDL.h"
#include "include\SDL_render.h"
#pragma comment (lib, "lib/SDL2.lib")
#pragma comment (lib, "lib/SDL2main.lib")

using namespace std;

int main(int argc, char* args[]) {
	int he = 640, wi = 520;

	SDL_Init(SDL_INIT_EVERYTHING); //Comen�a el codic

	SDL_Rect rectangle;
	SDL_Window* window;
	SDL_Renderer* renderer;

	window = SDL_CreateWindow("Quadrat", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, wi, he, 0);//Crear la pestanya amb les mides que vulguis

	/* We must call SDL_CreateRenderer in order for draw calls to affect this window. */
	renderer = SDL_CreateRenderer(window, -1, 0);
	SDL_SetRenderDrawColor(renderer, 250, 0, 0, 250);
	SDL_RenderClear(renderer); // Posa el color a la pantalla


	rectangle.x = 50;
	rectangle.y = 50;
	rectangle.w = 100;
	rectangle.h = 100;

	SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);
	
	SDL_RenderFillRect(renderer, &rectangle);

	SDL_RenderPresent(renderer);// Mostra la pantalla


		SDL_Event(event);
		
		while (1) {
			while (SDL_PollEvent(&event)) {

				switch (event.type) {

				case SDL_KEYDOWN: // Si hay alguna tecla apretada entra 
					/* Mira que tecla es la que esta apretada */
					switch (event.key.keysym.sym) {
					case SDLK_LEFT: {
						if (rectangle.x > 0)
							rectangle.x -= 10;
						break; }
					case SDLK_RIGHT:
						if (rectangle.x < (wi-rectangle.w))
						rectangle.x += 10;
						break;
					case SDLK_UP:
						if (rectangle.y > 0)
						rectangle.y -= 10;
						break;
					case SDLK_DOWN:
						if (rectangle.y < (he-rectangle.h))
						rectangle.y += 10;
						break;
					default:
						break;
					}
				default:
					break;
				}

			}
			SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);

			SDL_RenderClear(renderer); //Abans de pintar.

			SDL_SetRenderDrawColor(renderer, 0, 0, 255, 255);

			SDL_RenderFillRect(renderer, &rectangle);

			SDL_RenderPresent(renderer);
		}
	SDL_Quit();

	system("pause");
	return EXIT_SUCCESS;
}


